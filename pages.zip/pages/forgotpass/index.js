import React, { Component } from 'react';
import {
  View,
  Text,
  StatusBar,
} from 'react-native';

import styles from './styles';
import { colors } from 'styles';

class HomeScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params = {} } = navigation.state;
    return {
      title: 'Recuperar senha',
      headerStyle: {
        backgroundColor: colors.sucess,
        borderBottomWidth: 0,
      },
      headerTintColor: colors.white,
      headerTruncatedBackTitle: null,
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <StatusBar
          backgroundColor={colors.bluelight}
          barStyle="light-content"
        />
        <View style={styles.box}>
          <Text style={styles.title}>Pagina de teste</Text>
        </View>
      </View>
    );
  }
}

export default HomeScreen;