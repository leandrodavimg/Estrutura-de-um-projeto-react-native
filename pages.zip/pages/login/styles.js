import { StyleSheet } from 'react-native';

import { colors } from 'styles';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: colors.info,
    alignItems: 'center',
    justifyContent: 'center',
  },
  box: {
    margin: 40,
  },
  title: {
    color: colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  content: {
    color: colors.white,
    fontSize: 14,
  },
});

export default styles;