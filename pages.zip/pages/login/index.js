import React, { Component } from 'react';
import {
  View,
  Text,
  StatusBar,
  YellowBox,
  TouchableOpacity,
} from 'react-native';
import { createStackNavigator } from 'react-navigation';

import styles from './styles';
import { colors } from 'styles';

YellowBox.ignoreWarnings(['Warning: isMounted(...) is deprecated', 'Module RCTImageLoader']);

class HomeScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params = {} } = navigation.state;
    return {
      title: 'Ordem de pagamento',
      headerStyle: {
        backgroundColor: colors.sucess,
        borderBottomWidth: 0,
      },
      headerTintColor: colors.white,
      headerTruncatedBackTitle: null,
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <StatusBar
          backgroundColor={colors.bluelight}
          barStyle="light-content"
        />
        <View style={styles.box}>
          <Text style={styles.title}>Pagina de teste</Text>
        </View>
        <TouchableOpacity onPress={() => this.props.navigation.navigate('Newuser')}>
          <Text>Criar conta</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => this.props.navigation.navigate('Forgotpass')}>
          <Text>Recuperar senha</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export default HomeScreen;